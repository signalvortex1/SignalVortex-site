
# SignalVortex — Live Token Movers

Static site that pulls live pairs from **Dexscreener API**, shows Top 10 movers with **1m / 5m / 24h** tabs, plus **FDV, Liquidity, Market Cap, Circulating Supply**, and mini sparkline. Includes a **Low Cap (<$100k FDV)** toggle and a **24h Daily Digest** with copy-to-clipboard for Telegram posts.

## Deploy (Netlify, recommended)
1. Create a repo (e.g., `signalvortex-site`) and upload all files in this folder.
2. In Netlify: **Add new site → Import from Git** → choose this repo → Deploy.
3. Done. Every push auto-deploys.

## Deploy (GitHub Pages, optional)
- Settings → Pages → Source: `Deploy from a branch` → Branch: `main` → `/root`.

## Notes
- API used: `https://api.dexscreener.com/latest/dex/search?q=USDT` filtered to chains: solana, base, ethereum, bsc.
- If you want tighter results (e.g., chain-specific or meme-only), change the query in `assets/app.js`.
