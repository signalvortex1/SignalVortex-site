
const grid = document.querySelector('#grid');
const timeBtns = document.querySelectorAll('[data-time]');
const lowCapToggle = document.querySelector('#lowcap');
const digestEl = document.querySelector('#digest');
const copyBtn = document.querySelector('#copyDigest');
const REFRESH_MS = 120000; // 2 min
let activeTime = '1m';
let lowCap = false;

// Chains to include
const ALLOWED_CHAINS = new Set(['solana','base','ethereum','bsc']);

// Skeletons while loading
function showSkeleton(n=8){
  grid.innerHTML = '';
  for(let i=0;i<n;i++){
    const sk = document.createElement('div');
    sk.className = 'skeleton';
    grid.appendChild(sk);
  }
}

// Format helpers
const fmtUSD = (v)=> v==null ? '—' : (v>=1e9? `$${(v/1e9).toFixed(2)}B` : v>=1e6? `$${(v/1e6).toFixed(2)}M` : `$${Number(v).toLocaleString(undefined,{maximumFractionDigits:2})}`);
const fmtNum = (v)=> v==null ? '—' : Number(v).toLocaleString();
const toPct = (v)=> (v==null||v==='—') ? '—' : `${Number(v).toFixed(2)}%`;

// Draw a simple sparkline from price data if provided, else skip
function sparklineSVG(points){
  if(!points || !points.length){ return `<div class="spark"></div>`; }
  const w=300,h=36,pad=2;
  const xs = points.map((_,i)=> i/(points.length-1));
  const min = Math.min(...points), max = Math.max(...points);
  const ys = points.map(v => (1-(v-min)/Math.max(1e-9,(max-min)))*(h-2*pad)+pad);
  const d = ys.map((y,i)=> `${i===0?'M':'L'} ${pad+xs[i]*(w-2*pad)} ${y}`).join(' ');
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <path d="${d}" fill="none" stroke="#23d18b" stroke-width="2"/>
  </svg>`;
}

// Fetch tokens from Dexscreener
async function fetchTokens(){
  // Endpoint note: dexscreener exposes a "latest/dex/tokens" & "latest/dex/search" endpoint.
  // We'll use the "search?q=" endpoint with a broad query to pull fresh pairs, then filter.
  const url = `https://api.dexscreener.com/latest/dex/search?q=USDT`;
  const res = await fetch(url);
  if(!res.ok) throw new Error('Dexscreener fetch failed');
  const data = await res.json();
  return (data.pairs||[]).filter(p => ALLOWED_CHAINS.has(p.chainId));
}

function pickSparkline(pair){
  // Dexscreener sometimes returns "priceChange.h24" only; no direct sparkline.
  // We'll synthesize a small sequence using 24h change + current price for a visual cue.
  const base = Number(pair.priceUsd||0);
  if(!base) return null;
  const p24 = Number(pair.priceChange?.['24h']||0);
  const steps = 20;
  const series = Array.from({length:steps}, (_,i)=> base * (1 + p24/100 * (i/(steps-1) - 1)));
  return series;
}

function render(tokens){
  // Filter low-cap if toggle is on
  let arr = tokens.filter(t => !lowCap || (t.fdvUsd && t.fdvUsd < 100000));

  // Sort by active timeframe
  arr.sort((a,b)=> Number(b.priceChange?.[activeTime]||-9999) - Number(a.priceChange?.[activeTime]||-9999));

  // Top 10 only
  arr = arr.slice(0,10);

  grid.innerHTML = '';

  for(const t of arr){
    const ch = t.priceChange?.[activeTime];
    const cls = ch>=0 ? 'pos' : 'neg';
    const circ = t.marketCap || t.fdvUsd; // Dexscreener often exposes fdvUsd; real circ may be null
    const spark = sparklineSVG(pickSparkline(t));

    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <div class="head">
        <div>
          <div class="symbol">${t.baseToken?.symbol || '—'}</div>
          <div class="helper">
            <span class="badge">${(t.chainId||'').toUpperCase()}</span>
            <span class="badge">${t.dexId || 'DEX'}</span>
          </div>
        </div>
        <div class="change ${cls}">${toPct(ch)}</div>
      </div>

      ${spark}

      <div class="kv">
        <div><b>Price</b>${t.priceUsd? `$${Number(t.priceUsd).toFixed(6)}` : '—'}</div>
        <div><b>FDV</b>${fmtUSD(t.fdvUsd)}</div>
        <div><b>Liquidity</b>${fmtUSD(t.liquidity?.usd)}</div>
        <div><b>Market Cap</b>${fmtUSD(t.marketCap || t.fdvUsd)}</div>
        <div><b>Circulating</b>${fmtNum(t.circulatingSupply || t.baseToken?.address)}</div>
        <div><b>Pair</b>${(t.pairAddress||'').slice(0,6)}…</div>
      </div>

      <div class="links">
        <a href="https://dexscreener.com/${t.chainId}/${t.pairAddress}" target="_blank">DexScreener</a>
        <a href="https://www.dextools.io/app/en/${t.chainId}/pair-explorer/${t.pairAddress}" target="_blank">DexTools</a>
        <a href="https://coinmarketcap.com/search/?q=${encodeURIComponent(t.baseToken?.symbol||'')}" target="_blank">CMC</a>
        <a href="https://www.coingecko.com/en/search?query=${encodeURIComponent(t.baseToken?.symbol||'')}" target="_blank">CoinGecko</a>
      </div>
    `;
    grid.appendChild(card);
  }

  // Build digest (top 5 by 24h)
  const digestList = [...tokens]
    .filter(t => ALLOWED_CHAINS.has(t.chainId))
    .sort((a,b)=> Number(b.priceChange?.['24h']||-9999) - Number(a.priceChange?.['24h']||-9999))
    .slice(0,5)
    .map(t => `${t.baseToken?.symbol||'—'} (${(t.chainId||'').toUpperCase()}) — $${Number(t.priceUsd||0).toFixed(6)} | 24h: ${toPct(t.priceChange?.['24h'])} | FDV: ${fmtUSD(t.fdvUsd)} | LQ: ${fmtUSD(t.liquidity?.usd)} | https://dexscreener.com/${t.chainId}/${t.pairAddress}`)
    .join('\n');

  digestEl.textContent = digestList || 'No data yet.';
}

async function refresh(){
  try{
    showSkeleton(8);
    const tokens = await fetchTokens();
    render(tokens);
  }catch(e){
    grid.innerHTML = `<div class="card">⚠️ Error fetching live data. Try again shortly.</div>`;
  }
}

timeBtns.forEach(btn=>btn.addEventListener('click',()=>{
  timeBtns.forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  activeTime = btn.dataset.time;
  refresh();
}));

lowCapToggle.addEventListener('click',()=>{
  lowCap = !lowCap;
  lowCapToggle.classList.toggle('active', lowCap);
  refresh();
});

// First load + 2 min auto-refresh
refresh();
setInterval(refresh, REFRESH_MS);

// Copy digest
copyBtn.addEventListener('click', async ()=>{
  await navigator.clipboard.writeText(digestEl.textContent || '');
  copyBtn.textContent = 'Copied! ✅';
  setTimeout(()=> copyBtn.textContent = 'Copy for Telegram', 1200);
});
